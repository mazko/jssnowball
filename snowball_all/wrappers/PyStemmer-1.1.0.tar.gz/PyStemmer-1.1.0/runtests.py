#!/usr/bin/env python

import doctest
doctest.testfile('docs/quickstart.txt')

