#include "Python.h"

#include "libstemmer.h"

typedef struct
{
  PyObject_HEAD
    
  void *ptr;
} SnowballStemmer;

/* -------------------------------------------------------------------------
 * Make other functions.
 * ------------------------------------------------------------------------- */

static PyObject *
Snowball_stem_str (SnowballStemmer *self, char *str)
{
#define INC 10
  int lim = INC;
  int z = 0, len;
  PyObject *strobj = NULL;
  sb_symbol * b;
  
  len = strlen (str);
  b = (sb_symbol *) malloc (lim * sizeof(sb_symbol));

  while(1)
    {
      int i = 0;
      const sb_symbol * stemmed;
      int ch = str[z++];
      
      if (z >= len)
        {
          free (b);
          return strobj;
        }
      while(1) 
        {
          if (z >= len)
            break;
          if (i == lim)
            {
              sb_symbol * newb;
              newb = (sb_symbol *) realloc (b, (lim + INC) * sizeof(sb_symbol));
               if (newb == 0) 
                 goto error;
               b = newb;
               lim = lim + INC;
            }
          /* force lower case: */
          if (isupper (ch))
            ch = tolower (ch);

          b[i++] = ch;
          ch = str[z++];
        }

      stemmed = sb_stemmer_stem (self->ptr, b, i);
          
      if (stemmed == NULL)
        goto error;
      else
        strobj = Py_BuildValue ("s", stemmed);
    }
error:
  PyErr_SetString (PyExc_TypeError, "Out of memory");

  if (b != 0) 
    free(b);
  
  return NULL;
}

/* -------------------------------------------------------------------------
 * Make Object Methods
 * ------------------------------------------------------------------------- */

static PyObject *
Stemmer_sb_stemmer_new (SnowballStemmer *self, PyObject *args)
{
  char *algorithm, *charenc;

  if (! (PyArg_ParseTuple(args, "ss", &algorithm, &charenc)))
    return NULL;

  self->ptr = sb_stemmer_new (algorithm, charenc);
  if (!self->ptr)
    {
      PyErr_SetString (PyExc_TypeError, "sb_stemmer_new error. look your language or charset again.");
      return NULL;
    }

  return (PyObject *) self;
}

static PyObject *
Stemmer_sb_stemmer_delete (SnowballStemmer *self, PyObject *args)
{
  if (!self->ptr)
    return (PyObject *) self;
    
  sb_stemmer_delete (self->ptr);
  self->ptr = NULL;
  
  return (PyObject *) self;
}

static PyObject *
Stemmer_sb_stemmer_str (SnowballStemmer *self, PyObject *args)
{
  char *str;

  if (!(PyArg_ParseTuple(args,"s",&str)))
    return NULL;
 
  if (!self->ptr)
    {
      PyErr_SetString (PyExc_TypeError, "No stemmer object. run new () method first.");
      return NULL;
    }
 
  return Snowball_stem_str (self, str);
}

static PyObject *
Stemmer_sb_stemmer_length (SnowballStemmer *self, PyObject *args)
{
  int len;
  
  if (!self->ptr)
    {
      PyErr_SetString (PyExc_TypeError, "No stemmer object. run new () method first.");
      return NULL;
    }

  len = sb_stemmer_length (self->ptr);
  
  return Py_BuildValue ("i", len);
}

/* -------------------------------------------------------------------------
 * Make Module Object
 * ------------------------------------------------------------------------- */

static PyMethodDef SnowballStemmer_Methods[] = 
{
  { "new", (PyCFunction) Stemmer_sb_stemmer_new, METH_VARARGS, "Test1"},
  { "delete", (PyCFunction) Stemmer_sb_stemmer_delete, METH_VARARGS, "Test2"},
  { "stem_str", (PyCFunction) Stemmer_sb_stemmer_str, METH_VARARGS, "Test3"},
  { "length", (PyCFunction) Stemmer_sb_stemmer_length, METH_VARARGS, "Test3"},
  { NULL, NULL, 0, NULL }
};

static void
SnowballStemmer_dealloc(SnowballStemmer *self)
{
  self->ob_type->tp_free ((PyObject *) self);
}

static PyObject *
SnowballStemmer_new (PyTypeObject *type, PyObject *args, PyObject *kwds)
{
  return (PyObject *) type->tp_alloc(type, 0);
}

/* This is just like __init__ method of class.  */
static int
SnowballStemmer_init (SnowballStemmer *self, PyObject *args, PyObject *kwds)
{
  return 0;
}

static PyTypeObject SnowballStemmerType = 
{
  PyObject_HEAD_INIT (NULL)
  0,                             /*ob_size*/
  "SnowballStemmer.init",        /*tp_name*/
  sizeof (SnowballStemmer),      /*tp_basicsize*/
  0,                             /*tp_itemsize*/
  /* methods */
  (destructor) SnowballStemmer_dealloc,  /*tp_dealloc*/
  (printfunc) 0,                 /*tp_print*/
  (getattrfunc) 0,               /*tp_getattr*/
  (setattrfunc) 0,               /*tp_setattr*/
  (cmpfunc) 0,                   /*tp_compare*/
  (reprfunc) 0,                  /*tp_repr*/
  0,                             /*tp_as_number*/
  0,                             /*tp_as_sequence*/
  0,                             /*tp_as_mapping*/
  (hashfunc) 0,                  /*tp_hash*/
  (ternaryfunc) 0,               /*tp_call*/
  (reprfunc) 0,                  /*tp_str*/

  /* Space for future expansion */
  0L,0L,0L,
  Py_TPFLAGS_DEFAULT | Py_TPFLAGS_BASETYPE, /*tp_flags*/
  "Snowball Stemmer object",     /* Documentation string */
  0,                     /* tp_traverse */
  0,                     /* tp_clear */
  0,                     /* tp_richcompare */
  0,                     /* tp_weaklistoffset */
  0,                     /* tp_iter */
  0,                     /* tp_iternext */
  SnowballStemmer_Methods,             /* tp_methods */
  0,                     /* tp_members */
  0,                         /* tp_getset */
  0,                         /* tp_base */
  0,                         /* tp_dict */
  0,                         /* tp_descr_get */
  0,                         /* tp_descr_set */
  0,                         /* tp_dictoffset */
  (initproc) SnowballStemmer_init,      /* tp_init */
  0,                         /* tp_alloc */
  SnowballStemmer_new,                 /* tp_new */
};

static PyObject *
sb_stemmer_available (PyObject *self, PyObject *args)
{
  PyObject *list;

  list = PyList_New (0);

  PyList_Append (list, PyString_FromString ("danish" ));
  PyList_Append (list, PyString_FromString ("dutch"));
  PyList_Append (list, PyString_FromString ("english"));
  PyList_Append (list, PyString_FromString ("finnish"));
  PyList_Append (list, PyString_FromString ("french"));
  PyList_Append (list, PyString_FromString ("german"));
  PyList_Append (list, PyString_FromString ("italian"));
  PyList_Append (list, PyString_FromString ("norwegian"));
  PyList_Append (list, PyString_FromString ("porter"));
  PyList_Append (list, PyString_FromString ("portuguese"));
  PyList_Append (list, PyString_FromString ("russian"));
  PyList_Append (list, PyString_FromString ("spanish"));
  PyList_Append (list, PyString_FromString ("swedish"));

  PyList_Sort (list);

  return list;
}

static PyMethodDef SnowballStemmer_Module_Methods[] = 
{
  { NULL }
};

void initSnowballStemmer(void)
{
  PyObject* m;

  if (PyType_Ready(&SnowballStemmerType) < 0)
    return;
  
  m = Py_InitModule3 ("SnowballStemmer", SnowballStemmer_Module_Methods, "Test");

  Py_INCREF (&SnowballStemmerType);
  PyModule_AddObject (m, "SnowballStemmer", (PyObject *) &SnowballStemmerType);
}

